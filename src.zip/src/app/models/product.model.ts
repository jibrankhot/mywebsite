export interface Product {
    id: number;
    name: string;
    desc: string;
    image: string;
    price: string;
}